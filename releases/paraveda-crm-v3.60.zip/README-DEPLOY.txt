Paraveda CRM v3.60 — نشر على الهوست
=====================================
1) public_html/index.html   → حطّو فـ public_html/ (بدّل القديم)
2) public_html/api.php      → نفس المكان (v3.45 — إلا كان عندك نفس النسخة ما تحتاجش تبدلو)
3) public_html/import.php   → نفس المكان (اختياري)
4) crm_data.json (SaaS فارغ ونقي):
   - إلا كاين المجلد ../crm-paraveda-data فوق public_html → حط crm-paraveda-data/crm_data.json تماك
   - إلا ماكاينش → حط public_html/crm_data.json فـ public_html/
   ⚠️ هادشي كيمسح كل الطلبيات والمنتوجات القديمة من السيرفر (هادشي اللي طلبتي).
5) فـ المتصفح: Ctrl+F5 (ولا Vider le cache).
دخول الأدمين: admin@paraveda.ma
