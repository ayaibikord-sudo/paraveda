Paraveda CRM v3.64 — نشر على الهوست (⚠️ هاد المرة 3 ملفات ضرورية)
================================================================
1) public_html/index.html   → فـ public_html/ (بدّل القديم)
2) public_html/api.php      → فـ public_html/ (بدّل القديم — v3.64 ضروري)
3) crm_data.json (فارغ + طابع المسح):
   - إلا كاين المجلد ../crm-paraveda-data فوق public_html → حط crm-paraveda-data/crm_data.json تماك (بدّل القديم)
   - إلا ماكاينش → حط public_html/crm_data.json فـ public_html/
4) فـ المتصفح: Ctrl+F5. أول مرة كيتحمّل، كيمسح الكاش القديم بوحدو ويعاود التحميل.
   البنات كذلك: أول مرة يفتحو، الكاش القديم ديالهم كيتمسح أوتوماتيك.
دخول الأدمين: admin@paraveda.ma
